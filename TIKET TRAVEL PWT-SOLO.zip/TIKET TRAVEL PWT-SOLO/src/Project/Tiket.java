
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;


import javax.swing.JOptionPane;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.Color;

/**
 *
 * @author Free User
 */
public class Tiket extends javax.swing.JFrame {
 String tanggal,bulan,tahun,jam;

    String Cetak,kelas;
    public Tiket() {
        initComponents();
       Dimension layar = Toolkit.getDefaultToolkit().getScreenSize();
    
    int x = layar.width/2-this.getSize().width/2;
    int y = layar.height/2-this.getSize().height/2;
    
    this.setLocation(x, y); 
    }
    

 public void kelas(){
      if (RbEkonomi.isSelected()){
                  TxtHarga.setText("");
        if (CbNopemberangkatan.getSelectedItem().equals("==PILIH KODE==")){   
         }
          if (CbNopemberangkatan.getSelectedItem().equals("PU01")){
             TxtHarga.setText("150000");
         }
               if (CbNopemberangkatan.getSelectedItem().equals("PU02")){
           
             TxtHarga.setText("180000");
         }
         if (CbNopemberangkatan.getSelectedItem().equals("PU03")){
           
              TxtHarga.setText("250000");                   
           }
       
            
        if (CbNopemberangkatan.getSelectedItem().equals("PS01")){
            
                   
             TxtHarga.setText("80000");
         }if (CbNopemberangkatan.getSelectedItem().equals("PS02")){
            
           
             TxtHarga.setText("120000");
         }if (CbNopemberangkatan.getSelectedItem().equals("PS03")){
            
              TxtHarga.setText("250000");                   
         }
        
        }
        if (RbVIP.isSelected()){
            TxtHarga.setText("");
         if (CbNopemberangkatan.getSelectedItem().equals("==PILIH KODE==")){   
         }
          if (CbNopemberangkatan.getSelectedItem().equals("PU01")){
            
             TxtHarga.setText("180000");
         }
               if (CbNopemberangkatan.getSelectedItem().equals("PU02")){
           
             TxtHarga.setText("210000");
         }
         if (CbNopemberangkatan.getSelectedItem().equals("PU03")){
          
              TxtHarga.setText("280000");                   
           }
       
            
        if (CbNopemberangkatan.getSelectedItem().equals("PS01")){
            
              
             TxtHarga.setText("100000");
         }if (CbNopemberangkatan.getSelectedItem().equals("PS02")){
            
         
             TxtHarga.setText("155000");
         }if (CbNopemberangkatan.getSelectedItem().equals("PS03")){
        
              TxtHarga.setText("280000");                   
         }   
        }   
 }
 public void jam(){
     
     if (Rbjam9.isSelected()){
         jam = Rbjam9.getText();
     }
     else if (Rbjam13.isSelected()){
         jam=Rbjam13.getText();
     }
     else if (Rbjam16.isSelected()){
         jam =Rbjam16.getText();
 }
     else if (Rbjam20.isSelected()){
         jam =Rbjam20.getText();
     }
 }
 
     
 public void cetak(){
    
       int h ;
        h=JOptionPane.showConfirmDialog(null, "Cetak tiket?", "Cetak", JOptionPane.YES_NO_OPTION ,JOptionPane.QUESTION_MESSAGE);
        if (h==JOptionPane.YES_OPTION){
            //tanggal
                    if (CbTanggal.getSelectedItem().equals("Pilih")){
                        tanggal="";
                    }else if (CbTanggal.getSelectedItem().equals("1")){
                        tanggal="1";
                     
                    }else if (CbTanggal.getSelectedItem().equals("2")){
                        tanggal="2";
                    }else if (CbTanggal.getSelectedItem().equals("3")){
                        tanggal="3";
                    }else if (CbTanggal.getSelectedItem().equals("4")){
                        tanggal="4";
                    }else if (CbTanggal.getSelectedItem().equals("5")){
                        tanggal="5";
                    }else if (CbTanggal.getSelectedItem().equals("6")){
                        tanggal="6";
                    }else if (CbTanggal.getSelectedItem().equals("7")){
                        tanggal="7";
                    }else if (CbTanggal.getSelectedItem().equals("8")){
                        tanggal="8";
                    }else if (CbTanggal.getSelectedItem().equals("9")){
                        tanggal="9";
                    }else if (CbTanggal.getSelectedItem().equals("10")){
                        tanggal="10";
                    }else if (CbTanggal.getSelectedItem().equals("11")){
                        tanggal="11";
                    }else if (CbTanggal.getSelectedItem().equals("12")){
                        tanggal="12";
                    }else if (CbTanggal.getSelectedItem().equals("13")){
                        tanggal="13";
                    }else if (CbTanggal.getSelectedItem().equals("14")){
                        tanggal="14";
                    }else if (CbTanggal.getSelectedItem().equals("15")){
                        tanggal="15";
                    }else if (CbTanggal.getSelectedItem().equals("16")){
                        tanggal="16";
                    }else if (CbTanggal.getSelectedItem().equals("17")){
                        tanggal="17";
                    }else if (CbTanggal.getSelectedItem().equals("18")){
                        tanggal="18";
                    }else if (CbTanggal.getSelectedItem().equals("19")){
                        tanggal="19";
                    }else if (CbTanggal.getSelectedItem().equals("20")){
                        tanggal="20";
                    }else if (CbTanggal.getSelectedItem().equals("21")){
                        tanggal="21";
                    }else if (CbTanggal.getSelectedItem().equals("22")){
                        tanggal="22";
                    }else if (CbTanggal.getSelectedItem().equals("23")){
                        tanggal="23";
                    }else if (CbTanggal.getSelectedItem().equals("24")){
                        tanggal="24";
                    }else if (CbTanggal.getSelectedItem().equals("25")){
                        tanggal="25";
                    }else if (CbTanggal.getSelectedItem().equals("26")){
                        tanggal="26";
                    }else if (CbTanggal.getSelectedItem().equals("27")){
                        tanggal="27";
                    }else if (CbTanggal.getSelectedItem().equals("28")){
                        tanggal="28";
                    }else if (CbTanggal.getSelectedItem().equals("29")){
                        tanggal="29";
                    }else if (CbTanggal.getSelectedItem().equals("30")){
                        tanggal="30";
                    }else if (CbTanggal.getSelectedItem().equals("31")){
                        CbTanggal.addItem("31");
                    }
        //Bulan
                    if (CbBulan.getSelectedItem().equals("Pilih")){
                        bulan="";
                    }else if(CbBulan.getSelectedItem().equals("Januari")){
                        bulan="Januari";
                    }else if(CbBulan.getSelectedItem().equals("Februari")){
                        bulan="Februari";
                    }else if(CbBulan.getSelectedItem().equals("Maret")){
                        bulan="Maret";
                    }else if(CbBulan.getSelectedItem().equals("April")){
                        bulan="April";
                    }else if(CbBulan.getSelectedItem().equals("Mei")){
                        bulan="Mei";
                    }else if(CbBulan.getSelectedItem().equals("Juni")){
                        bulan="Juni";
                    }else if(CbBulan.getSelectedItem().equals("Juli")){
                        bulan="Juli";
                    }else if(CbBulan.getSelectedItem().equals("Agustus")){
                        bulan="Agustus";
                    }else if(CbBulan.getSelectedItem().equals("September")){
                        bulan="September";
                    }else if(CbBulan.getSelectedItem().equals("Oktober")){
                        bulan="Oktober";
                    }else if(CbBulan.getSelectedItem().equals("November")){
                        bulan="November";
                    }else if(CbBulan.getSelectedItem().equals("Desember")){
                        bulan="Desember";
                    }
                 //tahun
                   if (CbTahun.getSelectedItem().equals("Pilih")){
                        tahun="";
                    }else if (CbTahun.getSelectedItem().equals("2021")){
                        tahun="2021";}
 
       if (RbVIP.isSelected()){
           kelas=RbVIP.getText();
       }
       if (RbEkonomi.isSelected()){
           kelas=RbEkonomi.getText();
       }
       Cetak=
              "Nama                             : "+TxtNama.getText()+
           "\n No Pemberangkatan                : "+CbNopemberangkatan.getSelectedItem()+
           "\n Kelas                            : "+kelas+""+
           "\n Jalur                            : "+Txtjalur.getText()+
           "\n Tujuan                           : "+Txttujuan.getText()+
           "\n Tanggal Keberangkatan            : "+tanggal+" "+bulan+" "+tahun+
           "\n Jam keberangkatan                : "+jam+
           "\n Harga                            : Rp. "+TxtHarga.getText();
       
        JOptionPane.showMessageDialog(null, Cetak ,"Data Pemesanan Tiket Travel" ,JOptionPane.INFORMATION_MESSAGE);
                
       
        if (h==JOptionPane.NO_OPTION){
            JOptionPane.showMessageDialog(null,"Silahkan periksa kembali","Cek",JOptionPane.INFORMATION_MESSAGE);
        }

 }
 }
 

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BtnGrpKelas = new javax.swing.ButtonGroup();
        BtnGrpJam = new javax.swing.ButtonGroup();
        kGradientPanel1 = new com.k33ptoo.components.KGradientPanel();
        Jjalur = new javax.swing.JLabel();
        CbTanggal = new javax.swing.JComboBox<>();
        Rbjam9 = new javax.swing.JRadioButton();
        Txttujuan = new javax.swing.JTextField();
        Rbjam20 = new javax.swing.JRadioButton();
        Rbjam13 = new javax.swing.JRadioButton();
        JnoPemberangkatan = new javax.swing.JLabel();
        Jtujuan = new javax.swing.JLabel();
        JbCetak = new javax.swing.JButton();
        Jrupiah = new javax.swing.JLabel();
        CbBulan = new javax.swing.JComboBox<>();
        jJudul = new javax.swing.JLabel();
        Rbjam16 = new javax.swing.JRadioButton();
        Jnama = new javax.swing.JLabel();
        jExitApp = new javax.swing.JButton();
        Jtanggal = new javax.swing.JLabel();
        CbNopemberangkatan = new javax.swing.JComboBox<>();
        CbTahun = new javax.swing.JComboBox<>();
        Txtjalur = new javax.swing.JTextField();
        Jkelas = new javax.swing.JLabel();
        Jjam = new javax.swing.JLabel();
        TxtNama = new javax.swing.JTextField();
        TxtHarga = new javax.swing.JTextField();
        Jharga = new javax.swing.JLabel();
        jClear = new javax.swing.JButton();
        kGradientPanel2 = new com.k33ptoo.components.KGradientPanel();
        RbEkonomi = new javax.swing.JRadioButton();
        kGradientPanel3 = new com.k33ptoo.components.KGradientPanel();
        RbVIP = new javax.swing.JRadioButton();
        Kkembali = new com.k33ptoo.components.KButton();
        jExit = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                formMouseReleased(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel1.setBackground(new Color(0,0,0,0));
        kGradientPanel1.setkBorderRadius(70);
        kGradientPanel1.setkEndColor(new java.awt.Color(0, 0, 153));
        kGradientPanel1.setkGradientFocus(450);
        kGradientPanel1.setOpaque(false);

        Jjalur.setFont(new java.awt.Font("Leelawadee UI", 1, 15)); // NOI18N
        Jjalur.setForeground(new java.awt.Color(255, 255, 255));
        Jjalur.setText("Jalur Pemberangkatan");

        CbTanggal.setFont(new java.awt.Font("Leelawadee UI Semilight", 0, 12)); // NOI18N
        CbTanggal.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tanggal", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "15", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "29", "29", "30", "31" }));
        CbTanggal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbTanggalActionPerformed(evt);
            }
        });

        BtnGrpJam.add(Rbjam9);
        Rbjam9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Rbjam9.setForeground(new java.awt.Color(255, 255, 255));
        Rbjam9.setText("09:00");
        Rbjam9.setOpaque(false);
        Rbjam9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Rbjam9ActionPerformed(evt);
            }
        });

        Txttujuan.setEditable(false);
        Txttujuan.setBackground(new Color(0,0,0,0));
        Txttujuan.setFont(new java.awt.Font("Leelawadee UI Semilight", 0, 14)); // NOI18N
        Txttujuan.setForeground(new java.awt.Color(255, 255, 255));
        Txttujuan.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 153, 255)));
        Txttujuan.setCaretColor(new java.awt.Color(255, 255, 255));
        Txttujuan.setOpaque(false);
        Txttujuan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxttujuanActionPerformed(evt);
            }
        });

        BtnGrpJam.add(Rbjam20);
        Rbjam20.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Rbjam20.setForeground(new java.awt.Color(255, 255, 255));
        Rbjam20.setText("20:00");
        Rbjam20.setOpaque(false);
        Rbjam20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Rbjam20ActionPerformed(evt);
            }
        });

        BtnGrpJam.add(Rbjam13);
        Rbjam13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Rbjam13.setForeground(new java.awt.Color(255, 255, 255));
        Rbjam13.setText("13:00");
        Rbjam13.setOpaque(false);
        Rbjam13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Rbjam13ActionPerformed(evt);
            }
        });

        JnoPemberangkatan.setFont(new java.awt.Font("Leelawadee UI", 1, 15)); // NOI18N
        JnoPemberangkatan.setForeground(new java.awt.Color(255, 255, 255));
        JnoPemberangkatan.setText("No Pemberangkatan");

        Jtujuan.setFont(new java.awt.Font("Leelawadee UI", 1, 15)); // NOI18N
        Jtujuan.setForeground(new java.awt.Color(255, 255, 255));
        Jtujuan.setText("Tujuan");

        JbCetak.setText("CETAK");
        JbCetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JbCetakActionPerformed(evt);
            }
        });

        Jrupiah.setFont(new java.awt.Font("Leelawadee UI", 3, 14)); // NOI18N
        Jrupiah.setForeground(new java.awt.Color(255, 255, 255));
        Jrupiah.setText("Rp.");

        CbBulan.setFont(new java.awt.Font("Leelawadee UI Semilight", 0, 11)); // NOI18N
        CbBulan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Bulan", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember" }));
        CbBulan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbBulanActionPerformed(evt);
            }
        });

        jJudul.setFont(new java.awt.Font("Leelawadee UI Semilight", 2, 36)); // NOI18N
        jJudul.setForeground(new java.awt.Color(255, 255, 255));
        jJudul.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jJudul.setText("P E M E S A N A N  T I K E T");

        BtnGrpJam.add(Rbjam16);
        Rbjam16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Rbjam16.setForeground(new java.awt.Color(255, 255, 255));
        Rbjam16.setText("16:00");
        Rbjam16.setOpaque(false);
        Rbjam16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Rbjam16ActionPerformed(evt);
            }
        });

        Jnama.setFont(new java.awt.Font("Leelawadee UI", 1, 15)); // NOI18N
        Jnama.setForeground(new java.awt.Color(255, 255, 255));
        Jnama.setText("Nama");

        jExitApp.setForeground(new java.awt.Color(204, 0, 0));
        jExitApp.setText("EXIT");
        jExitApp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jExitAppActionPerformed(evt);
            }
        });

        Jtanggal.setFont(new java.awt.Font("Leelawadee UI", 1, 15)); // NOI18N
        Jtanggal.setForeground(new java.awt.Color(255, 255, 255));
        Jtanggal.setText("Tanggal Keberangkatan");

        CbNopemberangkatan.setFont(new java.awt.Font("Leelawadee UI Semilight", 0, 12)); // NOI18N
        CbNopemberangkatan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "PILIH", "PU01", "PU02", "PU03", "PS01", "PS02", "PS03" }));
        CbNopemberangkatan.setOpaque(false);
        CbNopemberangkatan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbNopemberangkatanActionPerformed(evt);
            }
        });

        CbTahun.setFont(new java.awt.Font("Leelawadee UI Semilight", 0, 11)); // NOI18N
        CbTahun.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tahun", "2021" }));
        CbTahun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbTahunActionPerformed(evt);
            }
        });

        Txtjalur.setEditable(false);
        Txtjalur.setBackground(new Color(0,0,0,0));
        Txtjalur.setFont(new java.awt.Font("Leelawadee UI Semilight", 0, 14)); // NOI18N
        Txtjalur.setForeground(new java.awt.Color(255, 255, 255));
        Txtjalur.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 102, 255)));
        Txtjalur.setCaretColor(new java.awt.Color(255, 255, 255));
        Txtjalur.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Txtjalur.setOpaque(false);
        Txtjalur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtjalurActionPerformed(evt);
            }
        });

        Jkelas.setFont(new java.awt.Font("Leelawadee UI", 1, 15)); // NOI18N
        Jkelas.setForeground(new java.awt.Color(255, 255, 255));
        Jkelas.setText("Kelas");

        Jjam.setFont(new java.awt.Font("Leelawadee UI", 1, 15)); // NOI18N
        Jjam.setForeground(new java.awt.Color(255, 255, 255));
        Jjam.setText("Jam Keberangkatan");

        TxtNama.setBackground(new Color(0,0,0,0));
        TxtNama.setFont(new java.awt.Font("Leelawadee UI Semilight", 0, 14)); // NOI18N
        TxtNama.setForeground(new java.awt.Color(255, 255, 255));
        TxtNama.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 102, 204)));
        TxtNama.setCaretColor(new java.awt.Color(255, 255, 255));
        TxtNama.setOpaque(false);
        TxtNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtNamaActionPerformed(evt);
            }
        });

        TxtHarga.setEditable(false);
        TxtHarga.setBackground(new Color(0,0,0,0));
        TxtHarga.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        TxtHarga.setForeground(new java.awt.Color(255, 204, 204));
        TxtHarga.setText("0");
        TxtHarga.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 204, 255)));
        TxtHarga.setOpaque(false);
        TxtHarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtHargaActionPerformed(evt);
            }
        });

        Jharga.setFont(new java.awt.Font("Leelawadee UI", 1, 15)); // NOI18N
        Jharga.setForeground(new java.awt.Color(255, 255, 255));
        Jharga.setText("Harga");

        jClear.setText("C L E A R");
        jClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jClearActionPerformed(evt);
            }
        });

        kGradientPanel2.setFont(new java.awt.Font("Leelawadee UI", 0, 12)); // NOI18N
        kGradientPanel2.setkBorderRadius(30);
        kGradientPanel2.setOpaque(false);

        BtnGrpKelas.add(RbEkonomi);
        RbEkonomi.setFont(new java.awt.Font("Leelawadee UI", 0, 12)); // NOI18N
        RbEkonomi.setForeground(new java.awt.Color(255, 255, 255));
        RbEkonomi.setText("EKONOMI");
        RbEkonomi.setContentAreaFilled(false);
        RbEkonomi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RbEkonomiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout kGradientPanel2Layout = new javax.swing.GroupLayout(kGradientPanel2);
        kGradientPanel2.setLayout(kGradientPanel2Layout);
        kGradientPanel2Layout.setHorizontalGroup(
            kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(RbEkonomi, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        kGradientPanel2Layout.setVerticalGroup(
            kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(RbEkonomi)
                .addContainerGap())
        );

        kGradientPanel3.setkBorderRadius(30);
        kGradientPanel3.setOpaque(false);

        BtnGrpKelas.add(RbVIP);
        RbVIP.setFont(new java.awt.Font("Leelawadee UI", 0, 12)); // NOI18N
        RbVIP.setForeground(new java.awt.Color(255, 255, 255));
        RbVIP.setText("VIP");
        RbVIP.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        RbVIP.setOpaque(false);
        RbVIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RbVIPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout kGradientPanel3Layout = new javax.swing.GroupLayout(kGradientPanel3);
        kGradientPanel3.setLayout(kGradientPanel3Layout);
        kGradientPanel3Layout.setHorizontalGroup(
            kGradientPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(RbVIP, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        kGradientPanel3Layout.setVerticalGroup(
            kGradientPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(RbVIP)
                .addContainerGap())
        );

        Kkembali.setText("Kembali");
        Kkembali.setFont(new java.awt.Font("Leelawadee UI", 0, 14)); // NOI18N
        Kkembali.setkBorderRadius(45);
        Kkembali.setkEndColor(new java.awt.Color(255, 0, 204));
        Kkembali.setkHoverEndColor(new java.awt.Color(51, 0, 153));
        Kkembali.setkHoverForeGround(new java.awt.Color(255, 255, 204));
        Kkembali.setkHoverStartColor(new java.awt.Color(204, 51, 255));
        Kkembali.setkStartColor(new java.awt.Color(51, 0, 153));
        Kkembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KkembaliActionPerformed(evt);
            }
        });

        jExit.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jExit.setForeground(new java.awt.Color(204, 204, 204));
        jExit.setText("x");
        jExit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jExitMouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("T.1");

        javax.swing.GroupLayout kGradientPanel1Layout = new javax.swing.GroupLayout(kGradientPanel1);
        kGradientPanel1.setLayout(kGradientPanel1Layout);
        kGradientPanel1Layout.setHorizontalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(Kkembali, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jClear, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jExitApp, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JbCetak, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(69, 69, 69))
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addComponent(jJudul, javax.swing.GroupLayout.PREFERRED_SIZE, 908, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 42, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, kGradientPanel1Layout.createSequentialGroup()
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                        .addComponent(Jtujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(112, 112, 112))
                                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                        .addComponent(Jjam, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CbNopemberangkatan, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(Txttujuan, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                                        .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                            .addComponent(Rbjam9)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(Rbjam13)
                                            .addGap(22, 22, 22))
                                        .addComponent(Txtjalur)))
                                .addGap(76, 76, 76))
                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                .addComponent(Jharga, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Jrupiah, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(TxtHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Rbjam16))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, kGradientPanel1Layout.createSequentialGroup()
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, kGradientPanel1Layout.createSequentialGroup()
                                .addComponent(Jnama, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(120, 120, 120)
                                .addComponent(TxtNama, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(Jjalur, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JnoPemberangkatan, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(Jtanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(CbTanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(93, 93, 93)
                        .addComponent(CbBulan, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(Jkelas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(kGradientPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(kGradientPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(99, 99, 99))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(CbTahun, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(230, 230, 230))
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(Rbjam20)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jExit)
                .addGap(29, 29, 29))
        );

        kGradientPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {kGradientPanel2, kGradientPanel3});

        kGradientPanel1Layout.setVerticalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(jExit)
                        .addGap(23, 23, 23))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addComponent(jJudul)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Jnama, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TxtNama, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JnoPemberangkatan, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CbNopemberangkatan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Jjalur)
                            .addComponent(Txtjalur, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Txttujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Jtujuan)))
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Jkelas)
                            .addComponent(kGradientPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(kGradientPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 89, Short.MAX_VALUE)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CbTanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CbTahun, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CbBulan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Jtanggal))
                .addGap(32, 32, 32)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Rbjam9)
                    .addComponent(Jjam, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Rbjam13)
                    .addComponent(Rbjam16)
                    .addComponent(Rbjam20))
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Jharga)
                            .addComponent(TxtHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Jrupiah, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jClear, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Kkembali, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(JbCetak, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)
                        .addComponent(jExitApp)
                        .addGap(19, 19, 19))))
        );

        kGradientPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {kGradientPanel2, kGradientPanel3});

        getContentPane().add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 640));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void KkembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KkembaliActionPerformed
        // TODO add your handling code here:
        new TiketTravel().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KkembaliActionPerformed

    private void formMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseReleased
        // TODO add your handling code
    }//GEN-LAST:event_formMouseReleased

    private void Rbjam9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Rbjam9ActionPerformed
        // TODO add your handling code here:
        jam();
    }//GEN-LAST:event_Rbjam9ActionPerformed

    private void jExitAppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jExitAppActionPerformed
        // TODO add your handling code here:
        int e;
        e=JOptionPane.showConfirmDialog(null, "Apakah anda yakin ?" ,"E X I T" ,JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
        if (e==JOptionPane.YES_OPTION){
            dispose();
        }
    }//GEN-LAST:event_jExitAppActionPerformed

    private void RbVIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RbVIPActionPerformed
        // TODO add your handling code here:
        kelas();
    }//GEN-LAST:event_RbVIPActionPerformed

    private void JbCetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JbCetakActionPerformed
        // TODO add your handling code here:
        cetak();
    }//GEN-LAST:event_JbCetakActionPerformed

    private void CbTanggalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbTanggalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CbTanggalActionPerformed

    private void CbTahunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbTahunActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CbTahunActionPerformed

    private void TxtNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtNamaActionPerformed

    private void CbNopemberangkatanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbNopemberangkatanActionPerformed
        // TODO add your handling code here
        int harga,total;

        if (CbNopemberangkatan.getSelectedItem().equals("==PILIH KODE==")){
        }
        if (CbNopemberangkatan.getSelectedItem().equals("PU01")){
            Txtjalur.setText("Utara");
            Txttujuan.setText("PURWOKERTO-BOYOLALI");

        }
        if (CbNopemberangkatan.getSelectedItem().equals("PU02")){
            Txtjalur.setText("Utara");
            Txttujuan.setText("PURWOKERTO-TEMANGGUNG");

        }
        if (CbNopemberangkatan.getSelectedItem().equals("PU03")){
            Txtjalur.setText("Utara");
            Txttujuan.setText("PURWOKERTO-SOLO");

        }

        if (CbNopemberangkatan.getSelectedItem().equals("PS01")){

            Txtjalur.setText("Selatan");
            Txttujuan.setText("PURWOKERTO-CILACAP");

        }if (CbNopemberangkatan.getSelectedItem().equals("PS02")){

            Txtjalur.setText("Selatan");
            Txttujuan.setText("PURWOKERTO-KEBUMEN");

        }if (CbNopemberangkatan.getSelectedItem().equals("PS03")){
            Txtjalur.setText("Selatan");
            Txttujuan.setText("PURWOKERTO-SOLO");

        }
    }//GEN-LAST:event_CbNopemberangkatanActionPerformed

    private void CbBulanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbBulanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CbBulanActionPerformed

    private void TxtHargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtHargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtHargaActionPerformed

    private void TxtjalurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtjalurActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtjalurActionPerformed

    private void Rbjam16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Rbjam16ActionPerformed
        // TODO add your handling code here:
        jam();
    }//GEN-LAST:event_Rbjam16ActionPerformed

    private void RbEkonomiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RbEkonomiActionPerformed
        // TODO add your handling code here:
        kelas();
    }//GEN-LAST:event_RbEkonomiActionPerformed

    private void Rbjam13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Rbjam13ActionPerformed
        // TODO add your handling code here:
        jam();
    }//GEN-LAST:event_Rbjam13ActionPerformed

    private void Rbjam20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Rbjam20ActionPerformed
        // TODO add your handling code here:
        jam();
    }//GEN-LAST:event_Rbjam20ActionPerformed

    private void TxttujuanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxttujuanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxttujuanActionPerformed

    private void jClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jClearActionPerformed
        // TODO add your handling code here:
        clear();
    }//GEN-LAST:event_jClearActionPerformed

    private void jExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jExitMouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jExitMouseClicked
   
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tiket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tiket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tiket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tiket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tiket().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup BtnGrpJam;
    private javax.swing.ButtonGroup BtnGrpKelas;
    private javax.swing.JComboBox<String> CbBulan;
    private javax.swing.JComboBox<String> CbNopemberangkatan;
    private javax.swing.JComboBox<String> CbTahun;
    private javax.swing.JComboBox<String> CbTanggal;
    private javax.swing.JButton JbCetak;
    private javax.swing.JLabel Jharga;
    private javax.swing.JLabel Jjalur;
    private javax.swing.JLabel Jjam;
    private javax.swing.JLabel Jkelas;
    private javax.swing.JLabel Jnama;
    private javax.swing.JLabel JnoPemberangkatan;
    private javax.swing.JLabel Jrupiah;
    private javax.swing.JLabel Jtanggal;
    private javax.swing.JLabel Jtujuan;
    private com.k33ptoo.components.KButton Kkembali;
    private javax.swing.JRadioButton RbEkonomi;
    private javax.swing.JRadioButton RbVIP;
    private javax.swing.JRadioButton Rbjam13;
    private javax.swing.JRadioButton Rbjam16;
    private javax.swing.JRadioButton Rbjam20;
    private javax.swing.JRadioButton Rbjam9;
    private javax.swing.JTextField TxtHarga;
    private javax.swing.JTextField TxtNama;
    private javax.swing.JTextField Txtjalur;
    private javax.swing.JTextField Txttujuan;
    private javax.swing.JButton jClear;
    private javax.swing.JLabel jExit;
    private javax.swing.JButton jExitApp;
    private javax.swing.JLabel jJudul;
    private javax.swing.JLabel jLabel4;
    private com.k33ptoo.components.KGradientPanel kGradientPanel1;
    private com.k33ptoo.components.KGradientPanel kGradientPanel2;
    private com.k33ptoo.components.KGradientPanel kGradientPanel3;
    // End of variables declaration//GEN-END:variables
public void clear(){
CbNopemberangkatan.setSelectedItem("==pilih==");
    
TxtNama.setText("");
TxtHarga.setText("");
Txtjalur.setText("");
Txttujuan.setText("");
BtnGrpKelas.clearSelection();
BtnGrpJam.clearSelection();
CbNopemberangkatan.setSelectedItem("==PILIH==");
CbTanggal.setSelectedItem("Tanggal");
CbBulan.setSelectedItem("Bulan");
CbTahun.setSelectedItem("Tahun");
JOptionPane.showMessageDialog(null, "Data telah di clear" ,"Clear",JOptionPane.INFORMATION_MESSAGE);


}

  







}

